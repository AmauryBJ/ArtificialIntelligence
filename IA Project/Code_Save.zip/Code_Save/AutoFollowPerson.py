#For Robot
from jetbot import Robot
robot = Robot()
robotSpeed = 0.4
robotSpeedFollow = 0.6
robot.stop()

#Serial
import serial
ser = serial.Serial(    port="/dev/ttyTHS1", baudrate=115200)  # open serial port

import time

def current_milli_time():
    return round(time.time() * 1000)

import jetson.inference
import jetson.utils

net = jetson.inference.detectNet("ssd-mobilenet-v2", threshold=0.5)

#camera = jetson.utils.gstCamera(1280,720,"csi://0") 
camera = jetson.utils.gstCamera(1280,720,"/dev/video0")  

#display = jetson.utils.glDisplay("Follow",1280,720,0,0,0,0) # 'my_video.mp4' for file
#display = jetson.utils.videoOutput("rtp://192.168.1.169:1234") # 'my_video.mp4' for file
#display = jetson.utils.videoOutput("my_video.mp4") # 'my_video.mp4' for file

index = 0
width = 0
location = 0

Pwidth = 0
Plocation = 0

direction = ""

personFound = False
timeTillLastHuman = current_milli_time()
diffTimeTillLastHuman = 0

while 1:
#while display.IsOpen():

	img, width, height = camera.CaptureRGBA()
	detections = net.Detect(img, width, height)
	#display.RenderOnce(img, width, height)
	#display.SetTitle("Object Detection | Network {:.0f} FPS".format(net.GetNetworkFPS()))

	personFound = False
	direction = ""

	for detection in detections:

		index = detection.ClassID
		width = (detection.Width)
		location = (detection.Center[0])

		#If Person Detected
		if(index == 1):

			personFound = True
			timeTillLastHuman = current_milli_time()

			Pwidth = width
			Plocation = location


	diffTimeTillLastHuman = current_milli_time() - timeTillLastHuman

	#if(personFound == False and diffTimeTillLastHuman < 300):
	#	personFound = True

	if(personFound):
		#Right
		if(Plocation > 800):
			direction = "right"
			robot.right(robotSpeed)

		#Left
		elif(Plocation < 400):
			direction = "left"
			robot.left(robotSpeed)
			
		#Center
		else:
			direction = "center"
			robot.stop()

			if(Pwidth < 650):
				robot.forward(robotSpeedFollow)
			else:
				robot.stop()
	else:
		robot.stop()

	Pwidth = 0
	Plocation = 0

	#Debug
	print(str(current_milli_time()) + " -- Person : " + str(personFound) + " -- " + direction)

	#Led
	if(personFound):
		if(direction == "left"):
			ser.write(b'(PR)')     
		elif(direction == "right"):
			ser.write(b'(PL)')   
		elif(direction == "center"):
			ser.write(b'(PC)')   
	else:
		ser.write(b'(NP)')    




