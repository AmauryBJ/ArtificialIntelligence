import time
import qwiic_micro_oled

# Screen Width
LCDWIDTH = 64

disp = qwiic_micro_oled.QwiicMicroOled()
disp.begin()
disp.scroll_stop()
disp.set_font_type(0) # Set Font



disp.clear(disp.PAGE)
disp.clear(disp.ALL)
disp.set_cursor(0,0)
disp.print("||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||")
disp.display()

time.sleep(5) #Pause 10 sec

‡