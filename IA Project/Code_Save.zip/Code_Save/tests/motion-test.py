from jetbot import Robot
import time

robot = Robot()

robot.forward(0.9)
time.sleep(1.0) #1 second
robot.stop()
